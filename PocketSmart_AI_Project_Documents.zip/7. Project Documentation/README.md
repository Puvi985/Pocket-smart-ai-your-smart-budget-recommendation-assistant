# PocketSmart AI – Project Documentation

## 1. Project Overview
PocketSmart AI is a web-based budget planning assistant designed to help users distribute a fixed amount of money across practical categories.

The demonstrated application provides three planners:
- **Home Interior Budget Planner**
- **Party Event Budget Planner**
- **Jewellery Purchase Budget Planner**

## 2. Purpose
The application converts a user's budget and selected requirements into a structured spending plan. Instead of manually deciding how much to allocate to every category, the user receives a ready-to-view breakdown.

## 3. Key Features
- User registration and login interface
- Dashboard navigation
- Home interior planning
- Party/event planning
- Jewellery purchase planning
- Category-wise budget allocation
- Item descriptions
- History interface
- Gemini API utility for generative AI assistance

## 4. How to Use
### Home Interior
1. Open Home Planner.
2. Enter the total budget.
3. Enter the required home/interior details.
4. Submit the form.
5. Review the generated budget plan.

### Party Event
1. Open Party Planner.
2. Enter the budget.
3. Enter party details such as guest count and venue type.
4. Submit.
5. Review the allocation for food, venue, decoration/music and related items.

### Jewellery
1. Open Jewellery Planner.
2. Enter the budget.
3. Select the metal type.
4. Enter jewellery-related details.
5. Submit.
6. Review the category-wise jewellery budget.

## 5. Important Note
The amounts displayed by the planner are planning suggestions based on the application's configured logic. They should not be treated as guaranteed current market prices.

## 6. Security Note
The Gemini API key must be stored in an environment variable such as `GEMINI_API_KEY`. Never publish the actual key in source code or GitHub.

## 7. Future Enhancements
- Live product/market price integration
- Database-backed history
- User profile management
- Export budget as PDF
- Expense tracking
- Budget comparison
- More planner categories
- Improved AI recommendations
