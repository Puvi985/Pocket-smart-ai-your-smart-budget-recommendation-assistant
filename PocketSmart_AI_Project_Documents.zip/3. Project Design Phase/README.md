# PocketSmart AI – Project Design Phase

## 1. System Architecture

The application follows a simple web application architecture:

**User → Web Browser → Flask Application → Planner Logic / Gemini Utility → Result Page**

## 2. Main Components

### Frontend
HTML templates provide the user interface for:
- Home page
- Login and registration
- Dashboard
- Home planner
- Party planner
- Jewellery planner
- Result pages
- History

CSS provides the visual styling and layout.

### Backend
The Flask/Python backend manages:
- Routes
- Form input
- Budget calculations
- Category creation
- Result rendering
- Planner-specific logic

### AI Layer
`gemini_utils.py` provides the Gemini API configuration and a reusable function for generating responses from prompts.

### Configuration
`.env` stores sensitive configuration such as the Gemini API key. The key should remain private and should never be committed to a public repository.

## 3. Application Modules

| Module | Purpose |
|---|---|
| Authentication | Registration and login |
| Dashboard | Main navigation and user overview |
| Home Planner | Interior budget planning |
| Party Planner | Event budget planning |
| Jewellery Planner | Jewellery purchase planning |
| History | Previous planning records |
| Gemini Utility | AI response generation |
| Styling | Common CSS design |

## 4. Data Flow
1. User opens a planner.
2. User enters the required details.
3. Browser submits the form to Flask.
4. Flask validates/converts the input.
5. Planner logic creates category allocations.
6. AI utility can be used where AI-generated assistance is required.
7. Result data is sent to the appropriate result template.
8. User views the personalized plan.

## 5. Budget Allocation Design
The current implementation uses category-based percentage allocation for planner results. For example, the party planner shown in the project allocates portions of the total budget to buffet/dinner, venue rental/setup, and decoration/music.

This makes the allocation transparent and easy to modify.

## 6. User Interface Design
The completed interface uses:
- Consistent top navigation
- Blue-themed header
- Centered planner forms
- Section headings
- Category/result cards or tables
- Clear budget totals
- Action buttons
