# PocketSmart AI – Project Demonstration

## 1. Demonstration Objective
To demonstrate that PocketSmart AI can accept user planning details and display a structured budget plan through a web interface.

## 2. Demonstrated Screens
The supplied demonstration video shows the following completed pages:

### A. Home Interior Budget Planner
The page accepts a total budget and home/interior requirements. The result page displays category-wise allocations and item details.

### B. Party Event Budget Planner
The page accepts event budget and party details. The demonstrated result includes:
- Party Buffet Dinner
- Venue Rental & Setup
- Party Decoration & Music

The implementation uses category percentages to divide the total budget.

### C. Jewellery Purchase Budget Planner
The page accepts the total budget and metal type. The demonstrated implementation includes categories such as:
- Gold Necklace & Sets
- Gold Bangles Collection
- Gold Rings & Accessories

## 3. Technical Demonstration
The development video also shows successful local Flask requests for the planner and result routes. The recorded terminal responses include HTTP 200 responses for the main planner flows.

## 4. AI Demonstration
The source shown in the development video includes `gemini_utils.py`, where:
- `GEMINI_API_KEY` is loaded from environment variables.
- Gemini is configured.
- A generative model is initialized.
- `get_gemini_response(prompt)` is used as a reusable AI response function.

## 5. Final Outcome
PocketSmart AI provides a single web application with multiple practical budget-planning workflows. It combines a Flask backend, HTML/CSS frontend, rule-based budget allocation, and Gemini-based generative AI support.

## 6. Demo Checklist
- [x] Application starts successfully
- [x] Home planner opens
- [x] Home result page works
- [x] Party planner opens
- [x] Party result page works
- [x] Jewellery planner opens
- [x] Jewellery result page works
- [x] Gemini utility is configured
- [x] Result pages display budget categories
