# PocketSmart AI – Brainstorming & Ideation

## 1. Project Title
**PocketSmart AI – Smart Budget Planning Assistant**

## 2. Problem Statement
People often find it difficult to divide a limited budget across different requirements for a home interior project, party/event, or jewellery purchase. Manual planning can be time-consuming and may lead to overspending or missing important items.

## 3. Proposed Solution
PocketSmart AI is a web-based budget planning application that accepts a user's total budget and planning details, then presents a personalized budget breakdown with categories, suggested items, allocated amounts, and descriptions.

## 4. Main Ideas Considered
- Simple manual expense calculator
- Category-based budget planner
- AI-assisted budget recommendation system
- Separate planners for different real-life purchase/event needs
- Budget history/dashboard for viewing previous plans

## 5. Selected Idea
The selected solution combines a simple web interface with AI support and category-based budgeting. The current application provides three planning areas:
1. Home Interior Budget Planner
2. Party Event Budget Planner
3. Jewellery Purchase Budget Planner

## 6. Target Users
- Students and young adults
- Families planning purchases
- People organizing small events
- Users purchasing jewellery with a fixed budget
- Anyone who wants a quick structured spending plan

## 7. Expected Benefits
- Clear budget distribution
- Reduced manual calculation
- Easy-to-use interface
- Category-wise spending visibility
- Reusable planning for different needs

## 8. Future Ideas
- Expense tracking after purchase
- Saved plans and comparison
- More categories such as travel, education and shopping
- Price updates from external sources
- More advanced AI recommendations
