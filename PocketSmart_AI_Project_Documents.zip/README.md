# PocketSmart AI – Project Deliverables

This repository contains the project deliverables organized according to the eight-phase structure of the referenced AI/ML & GenAI project template.

## Project
**PocketSmart AI – Smart Budget Planning Assistant**

## Deliverables
1. Brainstorming & Ideation
2. Requirement Analysis
3. Project Design Phase
4. Project Planning Phase
5. Project Development Phase
6. Project Testing
7. Project Documentation
8. Project Demonstration

Each folder contains a `README.md` document containing the project-specific deliverable.

## Evidence Source
The documentation was prepared from the supplied project development/demo videos. The implementation shown includes Flask/Python, HTML/CSS, Gemini API configuration, and three budget planners: Home Interior, Party Event and Jewellery Purchase.

## Reference Structure
The folder names follow the eight-section structure of the referenced GitHub project template.
