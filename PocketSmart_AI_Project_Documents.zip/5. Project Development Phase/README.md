# PocketSmart AI – Project Development Phase

## 1. Technology Stack
- **Backend:** Python + Flask
- **Frontend:** HTML5 + CSS3
- **AI:** Google Gemini generative AI API
- **Configuration:** python-dotenv
- **Development Environment:** Visual Studio Code
- **Browser:** Modern web browser

## 2. Project Structure

The project shown in the development video follows a structure similar to:

```text
PocketSmartAI/
├── services/
├── static/
│   ├── css/
│   │   └── styles.css
│   └── uploads/
├── templates/
│   ├── base.html
│   ├── dashboard.html
│   ├── history.html
│   ├── home_planner.html
│   ├── home_result.html
│   ├── index.html
│   ├── jewelry_planner.html
│   ├── login.html
│   ├── party_planner.html
│   └── register.html
├── .env
├── gemini_utils.py
├── main.py
└── requirements.txt
```

## 3. Backend Development
`main.py` contains Flask routes for the planners and result pages.

The demonstrated application includes routes for:
- `/home_planner`
- `/home_result`
- `/party_planner`
- `/party_result`
- `/jewelry_planner`
- `/jewelry_result`

## 4. Gemini Integration
The development video shows:
- API key loaded from `GEMINI_API_KEY`
- Gemini configured in `gemini_utils.py`
- A generative model initialized
- A reusable `get_gemini_response(prompt)` function

## 5. Planner Logic
The planner routes receive form data and construct category-based budget plans.

Examples shown in the implementation:
- Party planner: buffet/dinner, venue rental/setup, decoration/music.
- Jewellery planner: metal-specific necklace/set, bangles and other jewellery/accessory categories.
- Home planner: home/interior categories with item descriptions.

## 6. Frontend Development
Separate HTML templates are used for each planner and result page. A shared CSS file maintains the visual appearance.

## 7. Security
The Gemini API key is kept in `.env`. The `.env` file should be excluded from GitHub using `.gitignore`.
