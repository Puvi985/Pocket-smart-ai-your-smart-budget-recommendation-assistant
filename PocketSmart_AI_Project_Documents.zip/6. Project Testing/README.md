# PocketSmart AI – Project Testing

## 1. Testing Objective
To verify that the PocketSmart AI application accepts valid inputs, processes them correctly, displays the expected budget results, and handles common input errors.

## 2. Functional Test Cases

| ID | Test Case | Expected Result |
|---|---|---|
| TC01 | Open home page | Home page loads successfully |
| TC02 | Open Home Interior Planner | Planner form is displayed |
| TC03 | Submit valid home budget | Home result page is displayed |
| TC04 | Open Party Event Planner | Party form is displayed |
| TC05 | Submit valid party budget | Party result page is displayed |
| TC06 | Open Jewellery Planner | Jewellery form is displayed |
| TC07 | Submit valid jewellery budget | Jewellery result page is displayed |
| TC08 | Enter invalid/non-numeric budget | Application uses validation/error handling instead of crashing |
| TC09 | Navigate between planner pages | Correct page opens |
| TC10 | Check result allocations | Category allocations follow the configured planner logic |
| TC11 | Gemini utility receives a valid prompt | Generated response is returned when API is available |
| TC12 | Gemini API error occurs | Error is handled and exposed without application crash |

## 3. Demonstration Evidence
The supplied project video shows successful HTTP responses from the local Flask application for:
- `/home_planner`
- `/home_result`
- `/party_planner`
- `/party_result`
- `/jewelry_planner`
- `/jewelry_result`

The browser video also shows result pages for Home Interior, Party Event and Jewellery planning.

## 4. Testing Result
The demonstrated flows reached their result pages successfully. The application was therefore suitable for the recorded project demonstration.

## 5. Additional Recommended Testing
Before final submission:
- Test zero and negative budgets.
- Test very large budgets.
- Test empty form fields.
- Test mobile-sized browser layouts.
- Test with Gemini API unavailable.
- Confirm `.env` is not uploaded to GitHub.
