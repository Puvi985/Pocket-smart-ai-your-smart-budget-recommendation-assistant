# PocketSmart AI – Requirement Analysis

## 1. Functional Requirements

### User Account
- User registration and login.
- User-specific dashboard access.
- History page for previous planning activity.

### Home Interior Planner
- Accept total budget.
- Accept home/interior-related inputs such as room and item requirements.
- Generate a category-wise budget plan.
- Display allocated amount, item name, description and price/quantity information.

### Party Event Planner
- Accept total budget and party details such as guest count and venue type.
- Generate categories such as buffet/dinner, venue setup, decoration and music.
- Display the suggested allocation and item details.

### Jewellery Planner
- Accept total budget and metal type.
- Generate jewellery categories and suggested items.
- Display allocated amounts and purchase details.

### AI Support
- Gemini API is configured through an environment variable.
- A reusable Gemini utility sends prompts to the configured generative model and returns the generated text.
- The application can use AI responses as an assistance layer for personalized planning.

## 2. Non-Functional Requirements
- Simple and responsive web interface.
- Fast response for normal user requests.
- Secure handling of API credentials through environment variables.
- Maintainable Python backend and HTML/CSS frontend.
- Clear and readable budget results.

## 3. Software Requirements
- Python
- Flask
- HTML5
- CSS3
- JavaScript/browser
- Google Gemini API / `google-generativeai` integration
- `python-dotenv`
- `requirements.txt`
- Visual Studio Code or another Python IDE
- Modern web browser

## 4. Hardware Requirements
- Computer/laptop
- Internet connection for API-enabled features
- Minimum 4 GB RAM recommended for development

## 5. Inputs
- Budget amount
- Planner-specific details
- Party guest count/venue information where applicable
- Jewellery metal type where applicable

## 6. Outputs
- Personalized budget summary
- Category-wise allocation
- Item descriptions
- Suggested prices/quantities where provided by the planner logic
- Total/remaining budget information

## 7. Constraints
- Suggestions are planning estimates, not guaranteed market prices.
- External AI/API availability can affect AI-assisted features.
- API keys must not be hard-coded or publicly uploaded.
