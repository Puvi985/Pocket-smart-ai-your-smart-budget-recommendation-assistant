# PocketSmart AI – Project Planning Phase

## 1. Project Objective
To develop a user-friendly web application that helps users create structured spending plans for selected real-life requirements while keeping the total budget visible.

## 2. Development Plan

| Phase | Activities | Deliverable |
|---|---|---|
| 1 | Problem identification | Problem statement |
| 2 | Brainstorming | Selected project idea |
| 3 | Requirement analysis | Functional/non-functional requirements |
| 4 | UI design | Planner pages and navigation |
| 5 | Backend development | Flask routes and planner logic |
| 6 | AI integration | Gemini utility |
| 7 | Testing | Test cases and corrections |
| 8 | Documentation | Project documents |
| 9 | Demonstration | Working application demo |

## 3. Major Milestones
- Create project folder and Python environment.
- Build Flask application.
- Create common navigation and page layout.
- Implement authentication pages.
- Implement Home Interior Planner.
- Implement Party Event Planner.
- Implement Jewellery Purchase Planner.
- Add result pages.
- Configure Gemini utility.
- Test form submission and result generation.
- Prepare documentation and demonstration.

## 4. Risk Management

| Risk | Mitigation |
|---|---|
| Invalid budget input | Validate and convert form values |
| API key exposure | Store key in `.env` and exclude it from Git |
| AI/API failure | Provide error handling and planner logic |
| Incorrect allocation | Check category percentages and totals |
| UI issues | Test pages in a modern browser |
| Unexpected form data | Use defaults and exception handling |

## 5. Completion Criteria
The project is considered ready for demonstration when:
- All three planners open correctly.
- Forms accept valid input.
- Result pages display budget categories.
- Allocations are calculated correctly.
- Navigation works.
- AI utility is configured safely.
- Major test cases pass.
